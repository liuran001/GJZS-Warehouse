# Magisk Module for ColorOS

feature

fix fingerprint when magiskhide enabled

remove developer options warning notification

