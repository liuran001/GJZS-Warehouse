##########################################################################################
#
# Magisk Module Installer Script
#
##########################################################################################
##########################################################################################
#
# Instructions:
#
# 1. Place your files into system folder (delete the placeholder file)
# 2. Fill in your module's info into module.prop
# 3. Configure and implement callbacks in this file
# 4. If you need boot scripts, add them into common/post-fs-data.sh or common/service.sh
# 5. Add your additional or modified system properties into common/system.prop
#
##########################################################################################

##########################################################################################
# Config Flags
##########################################################################################

product=`getprop ro.product.name`
miui=`getprop ro.build.version.incremental`

if [[ ! "$product" == "atom" ]]
then
  ui_print "此模块不适用于你的手机型号!"
  exit 2
fi

if [[ ! "$miui" == "V12.0.2.0.QJHCNXM" ]]
then
  ui_print "此模块不适用于你的系统版本!"
  exit 3
fi


# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false

# Set to true if you need to load system.prop
PROPFILE=true

# Set to true if you need post-fs-data script
POSTFSDATA=false

# Set to true if you need late_start service script
LATESTARTSERVICE=false

##########################################################################################
# Replace list
##########################################################################################

# Construct your own list here
REPLACE="
"

print_modname() {
  ui_print "*******************************"
  ui_print "     Module author: 嘟嘟ski    "
  ui_print "*******************************"

  ui_print "

  "
ui_print "
请重启手机后再进行如下操作：

step1. 打开【设置】
step2. 点击【显示】
step3. 点击【屏幕刘海与状态栏】
step4. 点击【隐藏屏幕刘海】
step5. 选择隐藏刘海的方式


如果你以后要更新系统了，请务必删除此模块再更新！

"

  ui_print "*******************************"
  ui_print "如何恢复：删除模块重启即可"
  ui_print "*******************************"
  ui_print " "
  ui_print " "
}

# Copy/extract your module files into $MODPATH in on_install.

on_install() {
  # The following is the default implementation: extract $ZIPFILE/system to $MODPATH
  # Extend/change the logic to whatever you want
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

# Only some special files require specific permissions
# This function will be called after on_install is done
# The default permissions should be good enough for most cases

set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH/system 0 0 0755 0644
  chmod -R 755 $MODPATH

  # Here are some examples:
  # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
  # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0     0       0644
}

# You can add more functions to assist your custom script code
