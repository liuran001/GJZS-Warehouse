#!/system/bin/sh
if [[ ! -f /data/adb/modules/STEPS-Switch/module.prop ]]; then
	mkdir -p /data/adb/modules/STEPS-Switch/
	echo 'id=STEPS-Switch
name=A-智能步数管理［Switch］
version=ON/OFF
versionCode=20210316
author=附属模块
description=控制主模块核心进程运行状态 [[ 开启此模块: 运行主模块核心进程 | 关闭此模块: 终止主模块核心进程 ]]' > /data/adb/modules/STEPS-Switch/module.prop
fi
