#!/system/bin/sh
DIR=${0%/*}
PROCESS1() {
ps -ef | grep "ASGuard_Process.sh" | grep -v grep | wc -l
}
until [[ "$(PROCESS1)" != "0" ]]; do
  nohup sh $DIR/Script/ASGuard_Process.sh $DIR 0 &
  sleep 2
done
exit 0