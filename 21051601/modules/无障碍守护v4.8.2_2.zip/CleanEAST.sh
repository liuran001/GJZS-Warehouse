#!/system/bin/sh
touch $(dirname $0)/disable
echo "waiting...."
sleep 3
rm $(dirname $0)/config/EAS.ini
settings put secure enabled_accessibility_services ""
rm $(dirname $0)/disable
echo "OK"
