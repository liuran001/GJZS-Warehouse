#BOOTMODE（布尔）：true如果模块已安装在Magisk应用中
#MODPATH （路径）：应在其中安装模块文件的路径

timer_start=`date "+%Y-%m-%d %H:%M:%S"`

LogPrint() { echo "$1" ; }

model="`grep_prop ro.product.system.model`"
version="`grep_prop version $MODPATH/module.prop`"
versioncode="`grep_prop versionCode $MODPATH/module.prop`"
var_version="`grep_prop ro.build.version.release`"
name="`grep_prop name $MODPATH/module.prop`"
description="`grep_prop description $MODPATH/module.prop`"
LogPrint "- **********该设备信息**********"
LogPrint "- 您的设备名称: $model"
LogPrint "- 系统版本: $var_version"
LogPrint "- ********正在安装的模块********"
LogPrint "- 名称：$name"
LogPrint "- 版本：$version"
LogPrint "- 版本号：$versioncode"
LogPrint "- 作者：沍澤"
LogPrint "- $description"
LogPrint "- 安装日期：$timer_start"
LogPrint "- **********更新日志***********"
LogPrint "- 注意：v3.0之后的版本更改了模块id，更新须卸载v3.0以前的版本"
LogPrint "- 卸载前请备份/Android/ASGuard.txt以防保存配置被删除"
LogPrint "- （尽管此版本会移除旧版模块的删除配置文件命令）"
LogPrint "- --------------------------------------"
LogPrint "- 4.0_Release：重构代码，集合v1.x和v2.x版本优点，能够同时保护一个APP的多个无障碍服务（辅助功能）开关，并且不会影响配置以外的APP的开关"
LogPrint ""
LogPrint "- v4.8.2更新日志"
LogPrint "- 新增：配备全功能配置UI (麻麻再也不用担心我不会改模块配置了)"
LogPrint "- 新增：增加两个开关，具体见ASGuard.conf文件或ASGuardUI"
LogPrint "- 改进：修改部分与log相关的代码"

LogPrint "- 已知问题：写入输入法的无障碍功能开关可能无法生效，原因我也不知道"
LogPrint "- "
LogPrint "- 提示：在Magisk列表关闭模块开关可暂时停止保护服务，关机前请记得打开~"
LogPrint "- "
LogPrint "- *******************************"
LogPrint "- "

if $BOOTMODE; then
#  touch $MODPATH/config/update
  if_update=1
else
  if_update=0
fi


LogPrint "- 进度(0/5)"
chmod 7777 $MODPATH/Script/ASGuard_Process.sh
chmod 7777 $MODPATH/Script/ASGuard_Function.sh

if [[ ! -f /data/media/0/Android/ASGuard.txt ]] && [[ ! -f /data/media/0/Android/ASGuard.conf ]]; then
  LogPrint "- 正在生成配置文件，请到目录/data/media/0/Android/ASGuard.conf查看修改"
  LogPrint ""
  LogPrint "========================提示======================"
  LogPrint "- 原始配置附部分可能包名，不需要可去除，安装完成后重启生效"
  LogPrint "================================================="
  LogPrint "-- 默认关闭开机清理电池优化白名单"
  LogPrint "-- 默认开启重复写入无障碍服务开关"
  LogPrint "-- 默认开启Magisk模块列表运行时间显示"
  LogPrint "-- 默认开启log日志"
  LogPrint "-- 默认开启开机覆盖原有开启的无障碍"
  LogPrint "-- 默认关闭开机开启无障碍后结束模块进程"
  LogPrint "- 如果您需要修改以上内容可到/Android/ASGuard.conf修改或重新刷入修改"
  
  conf="#面板日期：2021.05.10#作者：酷安@沍澤#QQ用户群：837934310#"
  conf="$conf\n#======================提示========================#"
  conf="$conf\n#==========原始配置附部分可能包名,不需要可去除==========#"
  conf="$conf\n#=================================================#"
  conf="$conf\n\n#已附包名如下"
  conf="$conf\n#com.omarea.vtools #Scene4"
  conf="$conf\n#con.fooview.android.fooview #FV悬浮球"
  conf="$conf\n#需要保护的APP包名请填在下面AS的\" \"内，一行一个！不要填在\" \"外面！否则无法正常运行！"
  conf="$conf\n#填在AS配置里的包名不需要填到package_Whitelist里面"
  conf="$conf\n\nAS=\"\ncom.omarea.vtools\ncom.fooview.android.fooview\n\n\""
  conf="$conf\n\n#这个是电池优化白名单列表，开机将自动加入电池优化白名单，修改此项重启生效"
  conf="$conf\n#一行一个包名，填在\" \"内！"
  conf="$conf\npackage_whitelist=\"\n\n\n\"\n"
  conf="$conf\n#是否开启Magisk模块列表运行时间显示"
  conf="$conf\n#开启：1 关闭：0"
  conf="$conf\ntimemarker=1\n"
  conf="$conf\n#是否开启开机清空电池优化白名单选项"
  conf="$conf\n#开启：1 关闭：0"
  conf="$conf\nwhitelistclear=0\n"
  conf="$conf\n#重复写入开关，如果无障碍服务无法运行的情况出现过于频繁可尝试开启此选项"
  conf="$conf\n#开启：1 关闭：0"
  conf="$conf\nrewrite=1\n"
  conf="$conf\n#是否开启log"
  conf="$conf\n#开启：1 关闭：0"
  conf="$conf\nlog=1\n"
  conf="$conf\n#开机是否覆盖原有已开启的无障碍功能开关（重启生效）"
  conf="$conf\n#开启：1 关闭：0"
  conf="$conf\ncover=1\n"
  conf="$conf\n#是否只进行开机开启无障碍功能（重启生效）"
  conf="$conf\n#如果是则在开启保存的无障碍后自动结束本模块服务进程"
  conf="$conf\n#此开关不影响开机清空电池优化白名单开关"
  conf="$conf#开启：1 关闭：0"
  conf="$conf\nstop=0\n"
  echo -e "$conf" > /data/media/0/Android/ASGuard.conf
  
else

  LogPrint "- 发现ASGuard配置文件"
  
  if [[ -f /data/media/0/Android/ASGuard.txt ]]; then
  
    LogPrint "- 正在转为新版配置格式并移除旧版配置"
    name_package=`sed -n p /data/media/0/Android/ASGuard.txt | sed '/^$/d'`
    
    LogPrint "-- 默认关闭开机清理电池优化白名单"
    LogPrint "-- 默认开启重复写入无障碍服务开关"
    LogPrint "-- 默认开启Magisk模块列表运行时间显示"
    LogPrint "-- 默认开启log日志"
    LogPrint "-- 默认开启开机覆盖原有开启的无障碍"
    LogPrint "-- 默认关闭开机开启无障碍后结束模块进程"
    LogPrint "-- 如果您需要修改以上内容可到/Android/ASGuard.conf修改或重新刷入修改"
    
    conf="#面板日期：2021.05.10#作者：酷安@沍澤#QQ用户群：837934310#"
    conf="$conf\n#======================提示========================"
    conf="$conf\n#需要保护的APP包名请填在下面AS的\" \"内，一行一个！不要填在\" \"外面！否则无法正常运行！"
    conf="$conf\n#填在AS配置里的包名不需要填到package_Whitelist里面"
    conf="$conf\n\nAS=\"\n${name_package}\n\n\"\n\n"
    conf="$conf\n#这个是电池优化白名单列表，开机将自动加入电池优化白名单，修改此项重启生效"
    conf="$conf\n#一行一个包名，填在\" \"内！"
    conf="$conf\npackage_whitelist=\"\n\n\n\"\n"
    conf="$conf\n#是否开启Magisk模块列表运行时间显示"
    conf="$conf\n#开启：1 关闭：0"
    conf="$conf\ntimemarker=1\n"
    conf="$conf\n#是否开启开机清空电池优化白名单选项"
    conf="$conf\n#开启：1 关闭：0"
    conf="$conf\nwhitelistclear=0\n"
    conf="$conf\n#重复写入开关，如果无障碍服务无法运行的情况出现过于频繁可尝试开启此选项"
    conf="$conf\n#开启：1 关闭：0"
    conf="$conf\nrewrite=1\n"
    conf="$conf\n#是否开启log"
    conf="$conf\n#开启：1 关闭：0"
    conf="$conf\nlog=1\n"
    conf="$conf\n#开机是否覆盖原有已开启的无障碍功能开关（重启生效）"
    conf="$conf\n#开启：1 关闭：0"
    conf="$conf\ncover=1\n"
    conf="$conf\n#是否只进行开机开启无障碍功能（重启生效）"
    conf="$conf\n#如果是则在开启保存的无障碍后自动结束本模块服务进程"
    conf="$conf\n#此开关不影响开机清空电池优化白名单开关"
    conf="$conf#开启：1 关闭：0"
    conf="$conf\nstop=0\n"
    echo -e "$conf" > /data/media/0/Android/ASGuard.conf
    
    rm /data/media/0/Android/ASGuard.txt
    
    LogPrint "- 完成"
    
  else
    . /data/media/0/Android/ASGuard.conf
    AS=`echo "$AS" | sort | uniq | sed '/^$/d'`
    package_whitelist="`echo "${package_whitelist}" | sort | uniq`"
    
    conf="#面板日期：2021.05.10#作者：酷安@沍澤#QQ用户群：837934310#"
    conf="$conf\n#======================提示========================"
    conf="$conf\n#需要保护的APP包名请填在下面AS的\" \"内，一行一个！不要填在\" \"外面！否则无法正常运行！"
    conf="$conf\n#填在AS配置里的包名不需要填到package_Whitelist里面"
    conf="$conf\n\nAS=\"\n${AS}\n\n\"\n"
    conf="$conf\n#这个是电池优化白名单列表，开机将自动加入电池优化白名单，修改此项重启生效"
    conf="$conf\n#一行一个包名，填在\" \"内！"
    conf="$conf\npackage_whitelist=\"${package_whitelist}\n\n\"\n"
    conf="$conf\n#是否开启Magisk模块列表运行时间显示"
    conf="$conf\n#开启：1 关闭：0"
    conf="$conf\ntimemarker=${timemarker}\n"
    conf="$conf\n#是否开启开机清空电池优化白名单选项"
    conf="$conf\n#开启：1 关闭：0"
    conf="$conf\nwhitelistclear=${whitelistclear}\n"
    conf="$conf\n#重复写入开关，如果无障碍服务无法运行的情况出现过于频繁可尝试开启此选项"
    conf="$conf\n#开启：1 关闭：0"
    conf="$conf\nrewrite=${rewrite}\n"
    conf="$conf\n#是否开启log"
    conf="$conf\n#开启：1 关闭：0"
    conf="$conf\nlog=${log}\n"
    conf="$conf\n#开机是否覆盖原有已开启的无障碍功能开关（重启生效）"
    conf="$conf\n#开启：1 关闭：0"
    conf="$conf\ncover=${cover}\n"
    conf="$conf\n#是否只进行开机开启无障碍功能（重启生效）"
    conf="$conf\n#如果是则在开启保存的无障碍后自动结束本模块服务进程"
    conf="$conf\n#此开关不影响开机清空电池优化白名单开关"
    conf="$conf#开启：1 关闭：0"
    conf="$conf\nstop=${stop}\n"
    echo -e "$conf" > /data/media/0/Android/ASGuard.conf
  fi
fi

LogPrint "- 进度(1/5)"
if [[ -f /data/adb/modules/huzeASP/module.prop ]]; then
  touch /data/adb/modules/huzeASP/remove
  LogPrint "- 发现旧版模块，以Magisk的方式移除"
fi

LogPrint "- 进度(2/5)"
if [[ -f /data/adb/modules/huzeASP/uninstall.sh ]]; then
  rm /data/adb/modules/huzeASP/uninstall.sh
  LogPrint "- 移除旧版模块卸载配置命令完成"
fi

LogPrint "- 进度(3/5)"
if [[ -f /data/media/0/Android/EAS.txt ]]; then
  tmpEAS=$(sed "s/:/\n/g" /data/media/0/Android/EAS.txt | sort | uniq)
  echo "$tmpEAS" > $MODPATH/config/EAS.ini
  rm /data/media/0/Android/EAS.txt
  LogPrint "- 旧目录发现EAS.txt，已复制内容至模块目录"
fi

LogPrint "- 进度(4/5)"
if [[ -f /data/adb/modules/huzeASGuard/config/EAS.txt ]]; then
  tmpEAS=$(sed "s/:/\n/g" /data/adb/modules/huzeASGuard/config/EAS.txt | sort | uniq)
  echo "$tmpEAS" > $MODPATH/config/EAS.ini
  LogPrint "- 发现旧EAS.txt，已复制内容至模块目录"
elif [[ -f /data/adb/modules/huzeASGuard/config/EAS.ini ]]; then
  echo "$(sed -n p /data/adb/modules/huzeASGuard/config/EAS.ini | sort | uniq)" > $MODPATH/config/EAS.ini
  LogPrint "- 发现旧EAS.ini，已恢复内容至更新目录"
fi

LogPrint "- 进度(5/5)"
timer_end=`date "+%Y-%m-%d %H:%M:%S"`
duration=`echo $(($(date +%s -d "${timer_end}") - $(date +%s -d "${timer_start}"))) | awk '{t=split("60 s 60 m 24 h 999 d",a);for(n=1;n<t;n+=2){if($1==0)break;s=$1%a[n]a[n+1]s;$1=int($1/a[n])}print s}'`
[[ -z $duration ]] || [[ $duration = "1s" ]] && duration="秒刷！"
if [[ $if_update = 1 ]]; then
  LogPrint "- 更新完成，耗时："$duration
else
  LogPrint "- 安装完成，耗时："$duration
fi
LogPrint "- 重启设备后生效"
