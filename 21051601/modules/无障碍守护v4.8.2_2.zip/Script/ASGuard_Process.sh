#!/system/bin/sh
#加载函数
[[ $reload -ne 1 ]] && Running_time=`date "+%Y-%m-%d %H:%M:%S"`

[[ -z $DIR ]] && DIR=$1
. $DIR/Script/ASGuard_Function.sh

#等待可读写，刚开机未解锁会导致写文件失败
sdcard_rw
change_prop "[开始运行]"
if ((log != 0)); then
  echo $inform > $logpath
  echo "Running Date $(date "+%y.%m.%d %H:%M:%S")" >> $logpath
else
  [[ -f $logpath ]] && rm $logpath
fi

#Read config dim : AS package_whitelist whitelistclear timemarker rewrite✓ mode✓ log✓
load_config
if [[ $reload -ne 1 ]]; then
  mylog ": Config Loading"
else
  mylog ": Config Reloading"
fi

#DIM dim : inform path logpath data proppath
DIM ${DIR}


#初始化
if ((reload != 1)); then
  if ((whitelistclear == 1)); then
    start_clean "${AS}\n${package_whitelist}" &
    mylog "[Whitelist] : It will Clean Default_Whitelist after 90s and add Config Whitelist"
  fi
fi

settings put secure accessibility_enabled 1

if ((reload != 1)); then
  mylog ": Loading AS: $(echo $AS)"
else
  mylog ": Reloading AS: $(echo $AS)"
fi


mylog ": Checking EAS.ini"
check_EAS

EAS=`read_EAS`

tmpEAST=`get_EAS`

[[ $cover != 1 ]] && tmpEAST=`get_difference "$tmpEAST" "$EAST"`
if [[ -n "$tmpEAST" ]]; then
  mylog ": Starting Services"
  if [[ $cover != 1 ]]; then
    read_EAST
    write_EAST "$tmpEAST" "$EAST"
  else
    write_EAST "$tmpEAST"
  fi
  mylog ": Turned on AccessibilityServices"
else
  mylog ": EAS empty"
fi
unset tmpEAST

#初始化大致完成
Ending_time=`date "+%Y-%m-%d %H:%M:%S"`
duration=`echo $(($(date +%s -d "${Ending_time}") - $(date +%s -d "${Running_time}"))) | awk '{t=split("60 s 60 m 24 h 999 d",a);for(n=1;n<t;n+=2){if($1==0)break;s=$1%a[n]a[n+1]s;$1=int($1/a[n])}print s}'`
[[ -z $duration ]] && duration="0s"
mylog ": Initialization completed. It took "$duration

unset Running_time
unset Ending_time

#初始化完成

[[ $stop = 1 ]] && exit 0
load_config
EAST=`read_EAST`
EAS=`read_EAS`
old_AS="$AS"
old_EAST="$EAST"
switch=1

#大循环
until ((running > 5))
do
  #模块开关打开则运行
  if [[ ! -f $DIR/disable ]];then
    #标记变量，确保在此分支连续多次运行只运行一次
    if ((switch == 0)); then
      switch=1
      change_prop "[重新运行]"
      reload=1
      . $DIR/Script/ASGuard_Process.sh
    fi
    timer_start=`date "+%Y-%m-%d %H:%M:%S"`
    load_config
    until ((running != 1))
    do
      #标记变量，确保在此分支连续运行多次只输出一次log
      if ((tip != 1)); then
        mylog "[ASGuard] : Service running"
        tip=1
      fi
      load_config
      EAS=`read_EAS`
      EAST=`read_EAST`
      if_AS "$AS" "$old_AS" &
      mark_time &
      if [[ "$EAST" != "$old_EAST" ]];then
        increase_EAST &
        decrease_EAST &
      fi
      wait
      #上面更改过EAST需要再读一次
      old_EAST=`read_EAST`
      old_AS="$AS"
      sleep 3
      [[ -f $DIR/disable ]] && running=0
    done
    if ((tip == 1)); then
      mylog "[ASGuard] : Service stop"
      tip=0
    fi
  else
    if ((switch == 1)); then
      change_prop "[已被手动停止]"
      switch=0
    fi
    sleep 9
  fi
done
wait
exit 0