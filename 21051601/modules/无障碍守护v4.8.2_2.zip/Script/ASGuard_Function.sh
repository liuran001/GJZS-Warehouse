#!/system/bin/sh

inform="ASGuard v4.8.2_2(202105161) by 沍澤"
path=/data/media/0/Android/ASGuard.conf
logpath=/data/media/0/Android/log_ASG.txt

#等待正常读写，参数：无
sdcard_rw() {
  local file=/data/media/0/sdcard_rw_test.asg
  if [[ -f $file ]]; then
    rm $file
    while [[ -f $file ]]; do
      sleep 3
      rm $file
    done
  else
    touch $file
    until [[ -f $file ]]; do
      sleep 3
      touch $file
    done
    rm $file
  fi
}

#加载常量，参数：模块运行根目录
DIM() {
  if [[ -n $1 ]]; then
    data=$DIR/config/EAS.ini
    proppath=$DIR/module.prop
    echo "Loading Path \"$1\""
    return 0
  else
    echo "Empty Path"
    return 1
    exit 1
  fi
}

#加入电池优化白名单，参数：白名单包名
add_whitelist() {
  if [[ -n "$1" ]]; then
    local var
    local dp
    local list
    var="${1} "
    dp=(${var// / })
    for var in ${dp[@]}; do
      list="$list $var"
      dumpsys deviceidle whitelist +$var
    done
    mylog "[Whitelist] : Adding Whitelist <= $list"
    return 0
  else
    mylog "[Whitelist] : Empty whitelist"
    return 1
  fi
}

start_clean() {
  local tmp
  tmp="`echo -e "$1" | sed '/^$/d'`"
  clean_whitelist "$tmp" &
}
#清空电池优化白名单，参数：
clean_whitelist() {
  #别问，问就是直接复制的阿巴阿巴酱的清空电池优化白名单😂此段代码写入已在群里@当事人并告知👋🐟
  ## 这段for循环可以不产生额外文件而进行电池优化，感谢酷安@落叶凄凉TEL老哥提供的方法。
  sleep 90
  mylog "[Whitelist] : Cleaning Default_Whitelist"
  local app
  local line
  app=$(pm list packages --user 0 | sed 's/package://g')
  for line in $app; do
    dumpsys deviceidle whitelist -$line >/dev/null 2>&1
  done
  add_whitelist "$1"
  mylog "[Whitelist] : Finishing Whitelistclear"
  exit
}

get_time() {
echo $(date "+%H:%M:%S")
}

#输出日志自带时间，参数：日志内容
mylog() {
  if ((log != 0)); then
    echo "[$(get_time)] $1" >> $logpath
  fi
}

#更改prop描述 参数：修改内容
change_prop() {
  sed -i "s#^description=.*#description=开机自动开启且实时保护无障碍服务(辅助功能)，防止应用意外关闭导致无障碍服务连同关闭 "$1"#g" $proppath >/dev/null 2>&1
}

#更新显示运行时间，参数：无
mark_time() {
  if ((timemarker != 0)); then
    local timer_end
    local duration
    timer_end=`date "+%Y-%m-%d %H:%M:%S"`
    duration=`echo $(($(date +%s -d "${timer_end}") - $(date +%s -d "${timer_start}"))) | awk '{t=split("60 s 60 m 24 h 999 d",a);for(n=1;n<t;n+=2){if($1==0)break;s=$1%a[n]a[n+1]s;$1=int($1/a[n])}print s}'`
    change_prop "[本次截至$(get_time)已运行:"${duration}"]#g"
  fi
}

#加载配置，参数：无
load_config() {
  . $path
  AS=`echo "$AS" | sed '/^$/d'`
  if [[ -n "$AS" ]]; then
    running=1
    return 0
  else
    running=0
    return 1
  fi
}

#读取无障碍功能开关，参数：无
read_EAST() {
  local tmp
  tmp=`settings get secure enabled_accessibility_services`
  echo $tmp | sed 's/:/\n/g' | sed '/^$/d' | sort | uniq
}

#写入无障碍功能开关，参数：写入的名称 原始的名称
write_EAST() {
  local tmp1
  local tmp2
  tmp1=`echo $1 | sed 's/ /:/g'`
  [[ -n "$2" ]] && tmp2="`echo $2 | sed 's/ /:/g'`:"
  settings put secure enabled_accessibility_services "${tmp2}${tmp1}"
  if ((rewrite == 1)); then
    settings put secure enabled_accessibility_services "${tmp2}"
    sleep 0.1
    settings put secure enabled_accessibility_services "${tmp2}${tmp1}"
  fi
}

#读EAS.ini，空则创建写入
read_EAS() {
  #文件是否存在
  touch $data
  EAS=`sed '/^$/d' $data`
  if [[ -z "$EAS" ]]; then
    EAS=`get_EAST "$AS"`
    write_EAS "$EAS" 0
    echo "$EAS"
    return 1
  else
    echo "$EAS"
    return 0
  fi
}

#普通模式写入EAS.ini
#参数：写入EAS的文本 写入模式0/1(覆盖/追加)
write_EAS() {
  [[ -z "$1" ]] && return 1
  if [[ "$2" != "0" ]]; then
    echo "$1" >> $data
    mylog ": Adding Enable_Accessible_Services \"$(echo $1)\""
  else
    echo "$1" > $data
    mylog ": Covering Enable_Accessible_Services \"$(echo $1)\""
  fi
  EAS=`read_EAS`
}

#参数 EAS
check_EAS() {
  #检查和去除EAS.ini重复的名称并重新写入#
  touch $data
  EAS=`sed '/^$/d' $data | sort | uniq | sed '/^$/d'`
  if [[ -n "$EAS" ]]; then
    local dp1
    local dp2
    local var
    local tmpEAS
    dp1=(${EAS// / })
    for var in ${dp1[@]} ; do
      dp2=(${var//'/'/ })
      #比对名称第二部分的后半部分是否存在
      result=`echo -e "$tmpEAS" | grep $(echo ${dp2[1]} | sed 's/'${dp2[0]}'//g')`
      if [[ -z $result ]]; then
        result=`echo ${dp2[1]} | grep ${dp2[0]}`
        if [[ -z $result ]]; then
          tmpEAS="${tmpEAS}${dp2[0]}/${dp2[0]}${dp2[1]}\n"
        else
          tmpEAS="${tmpEAS}${var}\n"
        fi
      fi
    done
    EAS=`echo -e $tmpEAS | sort | uniq | sed '/^$/d'`
    write_EAS "$EAS" 0
  fi
  #更改数据重新读取
}

#获取包含AS或参数的EAS项(格式统一)，一般用于写入EAST
#参数：AS 
get_EAS() {
  [[ -z "$EAS" ]] && return 1
  #分隔文本
  local dp
  local dp1
  local dp2
  local var
  local tmp
  var="${EAS} "
  dp=(${var// / })
  if [[ -z "$1" ]]; then
    dp1="$AS"
  else
    dp1="$1"
  fi
  #检查开关是否存在配置包名，存在则放在后面写入
  for var in ${dp[@]}; do
    dp2=(${var//'/'/ })
    #从EAS.ini中取用户配置项的开关
    result=$(echo "$dp1" | grep ${dp2[0]})
    if [[ -n $result ]]; then
      tmp="$tmp$var\n"
    fi
  done
  echo -e $tmp | sed '/^$/d'
}

#获取EAST里面包含参数的项(格式不统一)，一般用于写入EAS
#参数：AS EAST
get_EAST() {
  if [[ -n "$1" ]]; then
    local dp1
    local var
    local tmp
    if [[ -z "$2" ]]; then
      var="$EAST "
    else
      var="$2 "
    fi
    dp1=(${var// / })
    for var in ${dp1[@]}; do
      dp2=(${var//'/'/ })
      result=`echo "$1" | grep ${dp2[0]}`
      if [[ -n $result ]]; then
        result=`echo -e "$tmp" | grep $var`
        if [[ -z $result ]]; then
          tmp="$tmp$var\n"
        fi
      fi
    done
    echo -e $tmp | sed '/^$/d'
  else
    return 1
  fi
}

#取差值
#参数：较大值 较小值
get_difference() {
  if [[ -z "$1" ]]; then
    return 1
  fi
  if [[ -z "$2" ]]; then
    echo "$1"
    return 0
  fi
  local result
  local tmp
  local m
  local l
  m=`echo "$1" | sort | uniq`
  l=`echo "$2" | sort | uniq`
  tmp=`echo -e "${m}\n${l}" | sort | uniq -d`
  result=`echo -e "${m}\n${tmp}" | sort | uniq -u | sed '/^$/d'`
  echo "$result"
}


#判断两个参数的差异
#参数：新AS 旧AS
if_AS() {
  #用户配置是否发生改变
  if [[ "$1" != "$2" ]]; then
    local tmpAS
    tmpAS=`get_difference "$1" "$2"`
    #判断有无增加的配置
    if [[ -z "$tmpAS" ]]; then
      mylog "[ASGuard] : ASGuard.conf AS_list = Change"
      return 1
    else
      mylog "[ASGuard] : ASGuard.conf AS_list = Increase"
    fi
    local tmpEAS
    local tmpEAST
    local logo
    local result1
    local result2
    add_whitelist "$tmpAS"
    EAST=`read_EAST`
    #从EAS文件中取开关
    tmpEAST=`get_EAS "$tmpAS"`
    #从EAST中取开关
    tmpEAS=`get_EAST "$tmpAS"`
    #根据以上开关出现空文本情况标记，0:全空 1:从EAS取空 2:从EAST取空 3:全不为空
    logo=0
    [[ -n "$tmpEAS" ]] && logo=$((logo+1))
    [[ -n "$tmpEAST" ]] && logo=$((logo+2))
    if ((logo == 0)); then
      mylog "[ASGuard] : \"EAS.ini\" and \"EAST\" are empty"
      return 1
    elif ((logo == 1)); then
      write_EAS "$tmpEAS" 1
      mylog "[ASGuard] : Mark \"$(echo $tmpEAS)\""
    elif ((logo == 2)); then
      write_EAST "$tmpEAST" "$EAST"
      mylog "[ASGuard] : Turn on \"$(echo $tmpEAST)\""
    else
      result1=`get_difference "$tmpEAST" "$tmpEAS"`
      result2=`get_difference "$tmpEAS" "$tmpEAST"`
      if [[ -n "$result1" ]]; then
        write_EAST "$result" "$EAST"
        mylog "[ASGuard] : Turn on \"$(echo $result1)\""
      fi    
      if [[ -n "$result2" ]]; then
        write_EAS "$result2" 1
        mylog "[ASGuard] : Mark \"$(echo $result2)\""
      fi
    fi
  fi
}

increase_EAST() {
  #取新增的开关
  local tmpEAS
  local iEAST
  iEAST=`get_difference "$EAST" "$old_EAST"`
  if [[ -n "$iEAST" ]]; then
    tmpEAS=`get_EAST "$AS" "$iEAST"`
    #不为空则写入
    if [[ -n "$tmpEAS" ]]; then
      tmpEAS=`get_difference "$tmpEAS" "$EAS"`
      [[ -n "$tmpEAS" ]] && write_EAS "$tmpEAS" 1
    fi
  fi
}

decrease_EAST() {
  local tmp
  local tmpEAST
  #取减少的开关的名称
  dEAST=`get_difference "$old_EAST" "$EAST"`
  if [[ -n "$dEAST" ]]; then
    tmpEAST=`get_EAST "$AS" "$dEAST"`
    if [[ -n "$tmpEAST" ]]; then
      #防止其它线程处理的数据无效，因此写入前再读一次
      EAST=`read_EAST`
      write_EAST "$tmpEAST" "$EAST"
      mylog "[ASGuard] : Protect \"$(echo $tmpEAST)\""
    fi
  fi
}
