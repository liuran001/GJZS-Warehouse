#!/system/bin/sh
#本代码可直接手动执行，自动杀死旧的进程，因此如果你对shell比较了解的话，可以自行调试本模块
#版本核心调用magick二进制文件，一款功能强大的图片处理命令，本人编译，有需要可以从./busybox/bin下自取magick二进制和./busybox/lib下动态链接库，如果你知道怎么把png动态库编译为静态的话，也可以联系我进行修改，万分感谢
until [[ $(dumpsys window policy | grep "mInputRestricted" | cut -d= -f2) == false ]]
do
	sleep 5
done
MODPATH=${0%/*}
export PATH=${MODPATH}/busybox/bin:${PATH}
shadow=${MODPATH}/shadow
tail -n +21 ${MODPATH}/service.sh > ${shadow}
chmod 777 ${shadow}
for i in $(ps -ef | grep ${MODPATH}/shadow | grep -v grep | awk '{print $1}')
do
	[ ${i} -gt 0 ] 2>/dev/null || break
	kill -9 ${i}
done
busybox sh ${shadow} &
exit

#!/data/adb/modules/shadow_screenshots/busybox/bin/sh
MODPATH=${0%/*}
source ${MODPATH}/module.prop
export PATH=${MODPATH}/busybox/bin:$PATH
export LD_LIBRARY_PATH=${MODPATH}/busybox/lib:${LD_LIBRARY_PATH}
rm -f ${MODPATH}/*.png ${MODPATH}/service.log ${MODPATH}/水印.png ${MODPATH}/*.bak ${MODPATH}/disable ${MODPATH}/*.jpg
list_wait=${MODPATH}/list_wait #等待执行套壳的列表
list_same=${MODPATH}/list_same #已完成和检测目录同时含有的列表
list_finish=${MODPATH}/list_finish #已经处理过的列表
list_path=${MODPATH}/list_path #监控目录的所有图片列表

[ -n "${format2}" ] || format2="未启用排除模式"
ls ${screenshots} | egrep "${format1}" | egrep -v "^$|:" | egrep -v "${format2}" > ${list_path}
[[ -f ${list_finish} ]] || touch ${list_finish}

#删除已完成中重复列表
sort ${list_finish} | uniq > ${list_wait}
cp -f ${list_wait} ${list_finish}


#删除已完成中已经过时的列表
cat ${list_finish} ${list_path} | sort | uniq -u > ${list_wait}
if [[ `cat ${list_wait} | egrep "${format1}" | egrep -v "${format2}" | wc -l` -gt 0 ]]; then
	while read line
	do
		[ -n ${line} ] && sed -i "/${line}/d" ${list_finish}
	done < ${list_wait}
fi
sleep 0.5
if [[ ${switch3} == yes ]]; then
	am force-stop com.android.providers.media > /dev/null
fi


log()
{
	if [[ ${switch5} == yes ]]; then
		echo "`date +%k:%M:%S` -$@"
		echo "`date +%k:%M:%S` -$@" >> ${MODPATH}/service.log
	fi
}

xm()
{
	j=1
	while :
	do
		eval t=\${t${j}}
		[ -n "${t}" ] || break
		hm1=${t%-*}
		hm2=${t#*-}
		if [ ${hm1} == ${hm2} ]; then
			log "无效休眠规则 ${t}"
		else
			h1=${hm1%:*}
			m1=${hm1#*:}
			h2=${hm2%:*}
			m2=${hm2#*:}
			s1=$(( ${h1} * 60 + ${m1} ))
			s2=$(( ${h2} * 60 + ${m2} ))
			h3=$(date +%k | sed "s/[^0-9]*//g")
			m3=$(date +%M | sed "s/[^0-9]*//g")
			s3=$(expr ${h3} \* 60 + ${m3} )
			[ ${s2} -gt ${s1} ] || s2=$(( ${s2} + 1440 ))
			[ ${s3} -gt ${s1} ] || s3=$(( ${s3} + 1440 ))
			if [ ${s3} -gt ${s1} ] && [ ${s2} -gt ${s3} ]; then
				s4=$(( ${s2} - ${s3} ))
				log "触发休眠规则 ${t} 本次休眠时间为${s4}分钟，休眠规则可自行修改module.prop中[t]参数"
				sleep ${s4}m
				log "休眠规则 ${t} 结束,发车"
			else
				log "休眠规则 ${t} 好累啊，怎么还不到点啊"
			fi
		fi
		j=$(( ${j} + 1 ))
	done
}

color()
{
	var="#"
	for k in `seq 1 6`
	do
		var=${var}$(printf %x $(( 15 - $((16#${color:$k:1})) )))
	done
	color=${var}
	log "颜色反转结果${color}"
}

cover()
{
	v_cover=${MODPATH}/png/${WH}/cover/v_${round}.png #竖屏四个大黑圆角
	if [[ ! -f ${v_cover} ]]; then
		log "圆角切块不存在，制作中"
		mkdir -p ${MODPATH}/png/${WH}/cover
		TMP=${MODPATH}/tmp.png
		#生成圆形切片
		convert \( -size ${round}x${round} xc:black -draw "fill white circle ${round},${round} ${round},0" \) -compose xor \( -size ${round}x${round} xc:none -draw "fill white circle ${round},${round} ${round},0" \) -composite ${TMP}
		#以圆形切片生成遮罩
		log "切块完成，制作遮罩"
		TEST=${MODPATH}/busybox/test
		convert \( \( \( ${TEST} -resize ${WH}! \) -compose over ${TMP} -composite \) -compose over \( +clone -flip \) -composite \) -compose over \( +clone -flop \) -composite ${v_cover}
		rm -f ${TMP}
		log "遮罩制作完成"
	fi
	h_cover=${MODPATH}/png/${WH}/cover/h_${round}.png #横屏四个大黑圆角
	if [[ ! -f ${h_cover} ]]; then
		convert -rotate 90 ${v_cover} ${h_cover}
	fi
	if [[ ${gravity} == h ]]; then
		cover=${h_cover}
	else
		cover=${v_cover}
	fi
}

shadow()
{
	dimen=${dimen%\%} #删除占比百分号
	W=$(( ${WH%x*} * ${dimen} / 100 )) #求出原图应该设置的宽度
	H=$(( ${WH#*x} * ${dimen%\%} / 100 )) #求出原图应该设置的高度
	cover #制作圆角遮罩
	#带圆角的纯色图,用来做原图边缘填充
	#竖屏
	color_cover_w_h=${MODPATH}/png/${WH}/round_color/${color}_${round}_${W}_${H}.png
	if [[ ! -f ${color_cover_w_h} ]]; then
		if [[ ! -d ${MODPATH}/png/${WH}/round_color ]]; then
			mkdir -p ${MODPATH}/png/${WH}/round_color
		fi
		color_png=${MODPATH}/png/${WH}/color/${color}.png
		if [[ ! -f ${color_png} ]]; then
			if [[ ! -d ${MODPATH}/png/${WH}/color ]]; then
				mkdir -p ${MODPATH}/png/${WH}/color
			fi
			log "生成纯色图片"
			convert -size ${WH} xc:"${color}" ${color_png}
		fi
		log "切出圆角纯色图片"
		convert ${color_png} -alpha set -compose dstout ${cover} -gravity center -resize ${W}x${H} -composite ${color_cover_w_h}
	fi
	#横屏
	color_cover_h_w=${MODPATH}/png/${WH}/round_color/${color}_${round}_${H}_${W}.png
	if [[ ! -f ${color_cover_h_w} ]]; then
		convert -rotate 90 ${color_cover_w_h} ${color_cover_h_w}
	fi
	if [[ ${gravity} == h ]]; then
		shadow=${color_cover_h_w}
	else
		shadow=${color_cover_w_h}
	fi
}

watermark()
{
	if [[ ${refresh} == yes ]] || [ ! -f ${MODPATH}/水印.png ]; then
	log "水印制作"
		if [ -n "${watermark}" ]; then
			watermark_tmp=${MODPATH}/watermark_tmp
			sum=${watermark_tmp}/sum
			mkdir -p ${sum}
			#逐行读取水印内容
			m=1
			echo "${watermark}" | sed "/^$/d" | while read line
			do
				mkdir -p ${watermark_tmp}/${m}
				#逐个读取水印内容
				n=1
				for l in ${line}
				do
					if [ -n "$(echo ${l} | sed -n "/^P[0-9]*$/p")" ]; then
						#判断是否为QQ头像
						qq=${l:1}
						curl -so ${watermark_tmp}/${m}/${n}.png "http://q1.qlogo.cn/g?b=qq&nk=${qq}&s=5"
						zhongxin=$(( ${wm_dimen2} / 2 ))
						banjing=$(( ${wm_dimen2} / 2 -2 ))
						if [ ! -f ${MODPATH}/png/yuan/${banjing}.png} ]; then
							if [ ! -d ${MODPATH}/png/yuan ]; then
								mkdir -p ${MODPATH}/png/yuan
							fi
							convert -size ${wm_dimen2}x${wm_dimen2} xc:none -draw "translate ${zhongxin},${zhongxin} circle 0,0 ${banjing},0" ${MODPATH}/png/yuan/${banjing}.png
						fi
						convert -background none \( -resize ${wm_dimen2}x${wm_dimen2} ${watermark_tmp}/${m}/${n}.png \) -alpha set -compose dstin ${MODPATH}/png/yuan/${banjing}.png -gravity center -composite ${watermark_tmp}/${m}/${n}.png
					elif [ -n "$(echo ${l} | sed -n "/^T[0-9]*$/p")" ]; then
						#判断是否为QQ昵称
						qq=${l:1}
						NAME="$(curl -s -H 'accept-language: zh-CN,en-US;q=0.9' -kL "https://r.qzone.qq.com/fcg-bin/cgi_get_portrait.fcg?uins=${qq}" | awk -F '"' '{print $6}' | iconv -f gb2312 -t utf-8)"
						convert -background none -fill "${color2}" -stroke "${color3}" -font ${font} -pointsize ${wm_dimen} label:"$NAME" -gravity center -annotate +0+0 "$NAME" ${watermark_tmp}/${m}/${n}.png
					elif [ -f "${l}" ]; then
						#判断是否为一个图片文件
						convert -resize ${wm_dimen2}x${wm_dimen2} ${l} ${watermark_tmp}/${m}/${n}.png
					elif [ -n "$(echo ${l} | sed -n "/^%.*%$/p")" ]; then
						#判断是否为变量 以下case内可以自己增添自己的变量
						eval customer="\$$(echo ${l} | sed "s/%//g")"
						if [ -n "${customer}" ]; then
							convert -background none -fill "${color2}" -stroke "${color3}" -font ${font} -pointsize ${wm_dimen} label:"${customer}" -gravity center -annotate +0+0 "${customer}" ${watermark_tmp}/${m}/${n}.png
						fi
					elif [ -n "$(echo "${l}" | egrep "\[[0-9]+\]")" ]; then
						#判断是否输入空格
						md5=$(date | md5sum)
						space=${md5:0:$(echo "${l}" | sed "s/[^0-9]//g")}
						convert -background none -fill "none" -font ${font} -pointsize ${wm_dimen} label:"${space}" -gravity center -annotate +0+0 "${space}" ${watermark_tmp}/${m}/${n}.png
					else
						#其他情况按照文字处理
						TEXT="$(echo "${l}" | sed "s/+_+/\n/g")"
						convert -background none -fill "${color2}" -stroke "${color3}" -font ${font} -pointsize ${wm_dimen} label:"${TEXT}" -gravity center -annotate +0+0 "${TEXT}" ${watermark_tmp}/${m}/${n}.png
					fi
					n=$(( $n + 1 ))
				done
				#横向合成该行内容
				if [ `ls ${watermark_tmp}/${m} | wc -l` -gt 1 ]; then
					convert -background none `ls ${watermark_tmp}/${m} | sed "s@^@${watermark_tmp}/${m}/@g"` -gravity center +append ${sum}/${m}.png
				else
					cp -f `ls ${watermark_tmp}/${m} | sed "s@^@${watermark_tmp}/${m}/@g"` ${sum}/${m}.png
				fi
				m=$(( $m + 1 ))
			done
			#纵向合成所有内容
			if [ `ls ${sum} | wc -l` -gt 1 ]; then
				convert -background none `ls ${sum} | sed "s@^@${sum}/@g"` -gravity ${plan} -append ${MODPATH}/水印.png
			else
				cp -f `ls ${sum} | sed "s@^@${sum}/@g"` ${MODPATH}/水印.png
			fi
			rm -rf ${watermark_tmp}
		fi
	fi
}

make_shadow()
{
	PNG_TMP=${MODPATH}/${i%.*}.png
	PNG_FINISH=${MODPATH}/shadow_${i%.*}.${format4}
	log "生成圆角图片"
	if [[ ${gravity} == h ]]; then
		NEW_WH="${H}x${W}"
	else
		NEW_WH="${W}x${H}"
	fi
	convert ${INPUTPNG} -alpha set -compose dstout ${cover} -gravity center -resize ${NEW_WH} -composite ${PNG_TMP}
	log "合成图片"
	#原图上放置圆角纯色图执行高斯模糊再放置缩小后的圆角原图
	convert ${INPUTPNG} -compose over ${shadow} -gravity center -composite $bg -compose over ${PNG_TMP} -gravity center -composite ${PNG_FINISH}
	if [ -f ${MODPATH}/水印.png ]; then
		convert ${PNG_FINISH} -compose over "${MODPATH}/水印.png" -gravity ${location} -geometry +${range_h}+${range_v} -composite ${PNG_FINISH}
	fi
	cp -f ${PNG_FINISH} ${OUTPNG}
	rm -f ${PNG_TMP} ${PNG_FINISH} ${INPUTPNG}
	if [[ ${switch4} == yes ]]; then
		log "刷新相册"
		timeout 2 am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE \
		-d file://${OUTPNG} > /dev/null 2>&1
		[[ $? -eq 0 ]] || log "媒体存储设备卡死"
	fi
}
test()
{
	if [ -f ${MODPATH}/disable ]; then
		sed -i "s#^description=.*#description=啊！我死了！叫不醒的那种！重新启用模块然后重启手机或者也可以root权限手动执行/data/adb/modules/shadow_screenshots/service.sh才能叫醒我#g" ${MODPATH}/module.prop
		exit 0
	else
		sed -i "s#^description=.*#description=手机截图自动套阴影，模块运行具体配置参数可以自行修改/data/adb/modules/shadow_screenshots/module.prop文件，点击禁用模块直接自杀给你看！#g" ${MODPATH}/module.prop
	fi
}




while :
do
	log "########################################"
	log "主循环开始"
	#引用变量
	source ${MODPATH}/module.prop
	test

	if [[ $(dumpsys window policy | grep "mInputRestricted" | cut -d= -f2) == false ]]; then
		sleeptime=${time1}
	else
		sleeptime=${time2}
	fi
	log "循环间隔时间为${sleeptime}秒"
	xm #判断是否休眠
	[ -n "${format2}" ] || format2="未启用排除模式"
	ls ${screenshots} | egrep "${format1}" | egrep -v "^$|:" | egrep -v "${format2}" > ${list_path}
	cat ${list_finish} ${list_path} | sort | uniq -d > ${list_same}
	cat ${list_path} ${list_same} | sort | uniq -u > ${list_wait}
	if [[ `cat ${list_wait} | egrep "${format1}" | egrep -v "${format2}" | wc -l` -ne 0 ]]; then
		log "检测到图片开始配置"
		cat ${list_wait} | egrep "${format1}" | egrep -v "${format2}" | while read i
		do
			log "准备制作$i"
			INPUT="$(find ${screenshots} -name "${i}" -type f | uniq)" #待制作图片绝对路径
			INPUTPNG="$MODPATH/input.${i##*.}"
			log $INPUT
			cp -f ${INPUT} ${INPUTPNG}
			#判断是否为区域截图
			message="$(identify ${INPUTPNG})"
			if [ ! "$(echo "${message}" | egrep "${WH}|${WH#*x}x${WH%x*}")" ]; then
				log "不符合要求，直接过"
			else
				if [ ! "$(echo "${message}" | grep "${WH}")" ]; then
					gravity=h
				else
					gravity=v
				fi
				#深色模式下阴影自动反色
				if [[ ${switch2} == yes ]]; then
					#判断是否为深色模式
					if [[ $(settings get system smart_dark_enable) -eq 1 ]] || \
					[[ $(settings get system dark_mode_enable) -eq 1 ]]; then
						color #反转颜色
					fi
				fi
				shadow #制作圆角纯色图片
				#是否覆盖原图
				if [[ ${switch1} == yes ]]; then
					switch4="no"
					format4=${i##*.}
					OUTPNG="${INPUT}"
				else
					if [[ ! -d ${screenshots_shadow} ]]; then
						mkdir -p ${screenshots_shadow}
					else
						if [[ ${screenshots} == ${screenshots_shadow} ]] || \
						[[ ${screenshots} == ${screenshots_shadow}/ ]]; then
							log "检测到未开启覆盖原图且生成图片保存位置与检测目录一致或位于检测目录下"
							if [[ ! -d ${screenshots_shadow} ]]; then
								mkdir -p ${screenshots_shadow}
								log "为防止触发bug无限套壳，已强制将阴影截图保存目录设置为${screenshots}_shadow"
							fi
						fi
					fi
					format4=${format3}
					OUTPNG="${screenshots_shadow}/${i%.*}_shadow.${format3}"
				fi
				watermark #检查水印
				log "开始制作"
				make_shadow
			fi
			if [ -n $(sed -n "/^${i}$/p" ${list_finish}) ]; then
				log "${i}完成写入清单"
				echo ${i} >> ${list_finish}
			else
				log "清单中已有此文件，你妈的，为什么又套娃"
			fi
		done
	fi
	log "一个循环结束，即将休眠${sleeptime}秒，可以通过module.prop修改"
	log "########################################"
	log ""
	sleep ${sleeptime}
done
