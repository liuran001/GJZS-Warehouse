#!/system/bin/sh
check_choise()
{
sleep 0.5
if [[ -n `getevent -lqc 1 | grep KEY_VOLUMEUP` ]]
then
	return 1
elif [[ -n `getevent -lqc 1 | grep KEY_VOLUMEDOWN` ]]
then
	return 0
else
	echo "-点锤子屏幕，爬一边去"
	check_choise
fi
}
[[ ${ARCH} != arm64 ]] && abort "-非arm64设备，爬"
unzip -o "${ZIPFILE}" "busybox/*" -d "${MODPATH}" >&2
tools_path="${MODPATH}/busybox/bin"
busybox="${tools_path}/busybox"
chmod 777 ${busybox}
for i in `${busybox} --list`
do
	ln -s ${MODPATH/_update/}/busybox/bin/busybox "${tools_path}/${i}"
done
ln -s ${MODPATH/_update/}/busybox/bin/magick ${tools_path}/convert
ln -s ${MODPATH/_update/}/busybox/bin/magick ${tools_path}/identify
if [[ $? -eq 0 ]]; then
	ui_print "-busybox安装成功"
else
	abort "-busybox安装失败,退出安装"
fi
source ${MODPATH}/module.prop

if [[ -d ${MODPATH/_update/}/png ]]; then
	cp -rf ${MODPATH/_update/}/png ${MODPATH}
else
	mkdir -p ${MODPATH}/png
fi
WH=`wm size | sed -n '$p' | sed 's/.* //g'`
sed -i 's@^\(WH=\).*@\1"'${WH}'"@g' ${MODPATH}/module.prop
[ -n "${format2}" ] || format2="未启用排除模式"
ls ${screenshots} | egrep "${format1}" | egrep -v "${format2}" > ${MODPATH}/list_path
ui_print "-当前系统分辨率:${WH}"
ui_print "-若不正确可修改prop解决"
var=$(find /storage/emulated/0/DCIM /storage/emulated/0/Pictures -iname "Screenshots" -type d)
case $(echo "${var}" | wc -l) in
	0)
		abort "-未找到系统截图目录，手动设置module.prop中 [screenshots] 变量后重新刷入"
		;;
	1)
		screenshots=${var}
		;;
	*)
		ui_print "-检测到多个截图目录:"
		ui_print "${var}"
		ui_print "-选择正确的目录"
		ui_print "-音量+ 确认"
		ui_print "-音量- 下一项"
		for i in ${var}
		do
			ui_print ""
			ui_print "-是否确认${i}"
			if check_choise; then
				screenshots=${i}
				break
			fi
		done
		;;
esac
[ -n "${screenshots}" ] || abort "-不设置监听目录你玩锤子呢，爬"
sed -i 's@^\(screenshots=\).*@\1"'${screenshots}'"@g' ${MODPATH}/module.prop
ui_print "-当前监听系统截图目录为:${screenshots}"
if [[ -f ${MODPATH/_update/}/list_finish ]]; then
	cp -f ${MODPATH/_update/}/list_finish ${MODPATH}
	ui_print "-检测到旧版本规则文件，已自动替换"
else
	if [[ -d ${screenshots} ]]; then
		num=`cat ${MODPATH}/list_path | egrep "${format1}" | egrep -v "${format2}" | wc -l`
		ui_print "-监听目录已有 [$num] 张截图，模块刷入重启后是否全部套阴影"
		ui_print "-这可能会浪费大量的性能，可能会卡，未经测试"
		ui_print "-音量键[+] 否"
		ui_print "-音量键[-] 是"
		if check_choise; then
			ui_print "-已选择 否"
			cp -f ${MODPATH}/list_path ${MODPATH}/list_finish
		else
			ui_print "-已选择 是"
			touch ${MODPATH}/list_finish
		fi
	fi
fi
ui_print "-模块配置懒得写一大堆的if了，自己手动改吧"
ui_print "-更多选项可修改模块module.prop内容重新刷入重启"
ui_print "-也可直接修改${MODPATH/_update/}/module.prop内容免重启即时生效"
ui_print "-图形化管理可以在阿巴酱群里获取app"
ui_print "-设置权限中，稍等"
set_perm_recursive "${MODPATH}" 0 0 0777 0777

echo "模块使用需知:
正确的模块目录树状图为
	busybox
		bin
			…
		fonts
			Roboto-Regular.ttf
		lib
			libbz2.so.1.0
			libfreetype.so
			libiconv.so
			libjpeg.so
			liblzma.so.5
			libpng16.so
			libtiff.so
			libz.so.1
		test
	module.prop
	service.sh
这些文件是不能被删除的

模块运行之后会多出来以下内容
	png
		…
	list_finish
	list_path
	list_same
	list_wait
	shadow
	水印.png
这些文件除了list_finish都可以删 但我不建议这么做 会重新生成 生成之前套壳的速度会变慢
list_finish很重要，如果不慎丢失会造成截图目录所有被正则允许的图片再次重复套壳，如果不慎删除了这个文件，可以立刻清理掉所有的截图防止模块占用大量资源
一般情况下list_same的大小加上list_wait的大小应该与list_path大小相等
list_wait是正在处理的图片列表，也就是说没有正在处理的话该文件大小应为0
模块正在处理图片的时候会生成几个png图片，处理完成后自动删除，不用担心
修改水印后需删除水印.png使其重新生成
如果模块没有运行起来第一部应该先修改module.prop中的log开关为yes，然后以root权限手动执行service.sh文件观察屏幕输出信息，有能力可以自行解决，没能力可以截图并提供模块目录下生成的service.log文件发给我
" > ${MODPATH}/模块运行须知.txt