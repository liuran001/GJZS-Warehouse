#!/sbin/sh

ui_print() { echo "$1"; }
HanShao () {
# 如果不需要，请设置为“真” Magisk to mount
# 给你的任何文件。大多数模块不需要
# 将此标志设置为真
SKIPMOUNT=false
# 如果需要加载system.prop，请设置为true。
PROPFILE=false
# 如果你需要post-fs-data脚本设置为true
POSTFSDATA=false
# 如果需要延迟启动服务脚本，请设置为true
LATESTARTSERVICE=false

BOOTMODE=true

# Construct your own list here
REPLACE="
"
}

set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644
}


#sh end

Finalizing() {
cd /
imageless_magisk || unmount_magisk_img
$BOOTMODE || recovery_cleanup
rm -rf $TMPDIR $MOUNTPATH $MODPATH/common
}
#这是一个虚拟文件，应该用适当的安装程序脚本替换

#如果您在本地创建模块以供个人使用或测试，
# download the script in the following URL:
# https://github.com/topjohnwu/Magisk/blob/master/scripts/module_installer.sh
# And replace this script with the downloaded script



TMPDIR=/dev/tmp
MOUNTPATH=/dev/magisk_img

# 默认权限
umask 022
ui_print "- 开始安装…………"
require_new_magisk() {
  ui_print "----------------------------"
  ui_print " 请安装最新的Magisk! "
  ui_print "----------------------------"
  exit 1
}

imageless_magisk() {
  [ $MAGISK_VER_CODE -gt 18100 ]
  return $?
}

#环境
OUTFD=1
ZIPFILE=/data/user/0/com.topjohnwu.magisk/cache/install.zip

mount /data 2>/dev/null

# 加载实用程序功能
if [ -f /data/adb/magisk/util_functions.sh ]; then
  . /data/adb/magisk/util_functions.sh
  NVBASE=/data/adb
else
  require_new_magisk
fi

# Preperation for flashable zips
setup_flashable

# 安装分区
mount_partitions

# 检测版本和架构
api_level_arch_detect

# 设置busybox和二进制文件
$BOOTMODE && boot_actions || recovery_actions

#准备安装
[ ! -f $TMPDIR/HanShao.sh ] && abort "文件不存在!"
HanShao

if imageless_magisk; then
  $BOOTMODE && MODDIRNAME=modules_update || MODDIRNAME=modules
  MODULEROOT=$NVBASE/$MODDIRNAME
else
  $BOOTMODE && IMGNAME=magisk_merge.img || IMGNAME=magisk.img
  IMG=$NVBASE/$IMGNAME
  request_zip_size_check "$ZIPFILE"
  mount_magisk_img
  MODULEROOT=$MOUNTPATH
fi

MODID=`grep_prop id $TMPDIR/module.prop`
MODPATH=$MODULEROOT/$MODID


ui_print "----------------------------"
ui_print "Powered by Magisk (@topjohnwu)"
ui_print "----------------------------"
#创建mod路径
rm -rf $MODPATH 2>/dev/null
mkdir -p $MODPATH
#开始安装
cp -rf $TMPDIR/system $MODPATH
# 删除占位符
rm -f $MODPATH/system/placeholder 2>/dev/null

# 自定义卸载程序
#[ -f $TMPDIR/uninstall.sh ] && cp -af $TMPDIR/uninstall.sh $MODPATH/uninstall.sh

# 自动安装
if imageless_magisk; then
  $SKIPMOUNT && touch $MODPATH/skip_mount
else
  $SKIPMOUNT || touch $MODPATH/auto_mount
fi

# 关于文件
$PROPFILE && cp -af $TMPDIR/system.prop $MODPATH/system.prop

# 模块信息
cp -af $TMPDIR/module.prop $MODPATH/module.prop
if $BOOTMODE; then
# 更新Magic Manager的信息
  if imageless_magisk; then
    mktouch $NVBASE/modules/$MODID/update
    cp -af $TMPDIR/module.prop $NVBASE/modules/$MODID/module.prop
  else
    mktouch /sbin/.magisk/img/$MODID/update
    cp -af $TMPDIR/module.prop /sbin/.magisk/img/$MODID/module.prop
  fi
fi

#XZai=$XZai
# post-fs-data 模式脚本
$POSTFSDATA && cp -af $TMPDIR/post-fs-data.sh $MODPATH/post-fs-data.sh
# service 模式脚本
$LATESTARTSERVICE && cp -af $TMPDIR/service.sh $MODPATH/service.sh
# 处理替换文件夹
for TARGET in $REPLACE; do
  mktouch $MODPATH$TARGET/.replace
done
ui_print "- 设置权限"
set_permissions

##########################################################################################
# Finalizing
##########################################################################################
Finalizing
#
ui_print "已安装完成，重启即可见证奇迹！"
	ui_print ""
	ui_print "遇见你是我无法预料的意外"
	ui_print ""
	ui_print "爱上你实属、情非得已"
	ui_print ""
	ui_print "我就是By：函少、酷安ID：情非得已c"
