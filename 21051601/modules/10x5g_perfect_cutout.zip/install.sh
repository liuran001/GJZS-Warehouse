##########################################################################################
#
# Magisk Module Installer Script
#
##########################################################################################
##########################################################################################
#
# Instructions:
#
# 1. Place your files into system folder (delete the placeholder file)
# 2. Fill in your module's info into module.prop
# 3. Configure and implement callbacks in this file
# 4. If you need boot scripts, add them into common/post-fs-data.sh or common/service.sh
# 5. Add your additional or modified system properties into common/system.prop
#
##########################################################################################

##########################################################################################
# Config Flags
##########################################################################################

# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false

# Set to true if you need to load system.prop
PROPFILE=true

# Set to true if you need post-fs-data script
POSTFSDATA=false

# Set to true if you need late_start service script
LATESTARTSERVICE=false

##########################################################################################
# Replace list
##########################################################################################

# Construct your own list here
REPLACE="
"

print_modname() {
  ui_print "*******************************"
  ui_print "     Module author: 嘟嘟ski    "
  ui_print "*******************************"

  ui_print "

  "
ui_print "
接下来，请按如下步骤操作：

step0. 重启手机！！
step1. 打开系统【设置】
step2. 点击【我的设备】
step3. 点击【全部参数】
step4. 连续点击【MIUI 版本】激活开发者选项
step5. 回退到【设置】首页
step6. 点击【更多设置】
step7. 点击【开发者选项】
step8. 使劲儿滑，找到【最小宽度】下方的【刘海屏】
step9. 点开【刘海屏】选项，选择【对齐物理缺口】
step10. 回退到【设置】首页
step11. 点击【显示】
step12. 点击【屏幕刘海与状态栏】
step13. 点击【隐藏屏幕刘海】
step14. 选最后一个【隐藏后状态栏在刘海外】


几个刘海屏选项几个的区别：
【对齐缺口并微调】
  隐藏刘海时状态栏对齐水滴高度，
  并略微垫高下巴高度
  最终分辨率：2340*1080

【对齐物理缺口】
  隐藏刘海时状态栏对齐水滴高度，
  最终分辨率：2344*1080

【无缺口】
  显示软件界面内容时，不为水滴预留空白区域

  "

  ui_print "*******************************"
  ui_print "如何恢复：删除模块并还原开发者选项"
  ui_print "*******************************"
  ui_print " "
  ui_print " "
}

# Copy/extract your module files into $MODPATH in on_install.

on_install() {
  # The following is the default implementation: extract $ZIPFILE/system to $MODPATH
  # Extend/change the logic to whatever you want
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

# Only some special files require specific permissions
# This function will be called after on_install is done
# The default permissions should be good enough for most cases

set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH/system 0 0 0755 0644
  chmod -R 755 $MODPATH

  # Here are some examples:
  # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
  # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0     0       0644
}

# You can add more functions to assist your custom script code
