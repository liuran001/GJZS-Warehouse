rm -rf /data/misc/dreamland

# Before v22
rm -rf /data/misc/riru/modules/dreamland

# After v22
rm -rf /data/adb/riru/modules/dreamland
