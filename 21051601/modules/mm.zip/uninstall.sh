# 这个脚本会在删除模块的时候执行

rm -f /data/media/0/mm
rm -f /data/media/mm
