# **SQLite3 for ARM设备**

## 介绍

为不自带sqlite3的机型挂载sqlite3二进制文件


## Links
[SQLite](https://www.sqlite.org/)  
[搞机助手重制版](https://gjzs.qqcn.site/)
